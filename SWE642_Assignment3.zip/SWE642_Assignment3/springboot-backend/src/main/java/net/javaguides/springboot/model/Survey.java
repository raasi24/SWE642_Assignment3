package net.javaguides.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "surveys")
public class Survey {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "street_address")
	private String StreetAddress;

	@Column(name = "city")
	private String City;

	@Column(name = "state")
	private String State;

	@Column(name = "zipcode")
	private String ZipCode;

	@Column(name = "email_id")
	private String emailId;

	public Survey() {

	}

	public Survey(String firstName, String lastName, String emailId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.StreetAddress = StreetAddress;
		this.City = City;
		this.State = State;
		this.ZipCode = ZipCode;
		this.emailId = emailId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStreetAddress() {
		return StreetAddress;
	}

	public void setStreetAddress(String StreetAddress) {
		this.StreetAddress = StreetAddress;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String City) {
		this.City = City;
	}

	public String getState() {
		return State;
	}

	public void setState(String State) {
		this.State = State;
	}

	public String getZipCode() {
		return firstName;
	}

	public void setZipCode(String ZipCode) {
		this.ZipCode = ZipCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
