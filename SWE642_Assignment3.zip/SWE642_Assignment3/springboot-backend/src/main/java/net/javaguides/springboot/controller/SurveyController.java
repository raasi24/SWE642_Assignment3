package net.javaguides.springboot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Survey;
import net.javaguides.springboot.repository.SurveyRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class SurveyController {

	@Autowired
	private SurveyRepository surveyRepository;

	// get all surveys
	@GetMapping("/surveys")
	public List<Survey> getAllSurveys() {
		return surveyRepository.findAll();
	}

	// create employee rest api
	@PostMapping("/surveys")
	public Survey createSurvey(@RequestBody Survey survey) {
		return surveyRepository.save(survey);
	}

	// get employee by id rest api
	@GetMapping("/surveys/{id}")
	public ResponseEntity<Survey> getSurveyById(@PathVariable Long id) {
		Survey survey = surveyRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Survey not exist with id :" + id));
		return ResponseEntity.ok(survey);
	}

	// update survey rest api

	@PutMapping("/surveys/{id}")
	public ResponseEntity<Survey> updateSurvey(@PathVariable Long id, @RequestBody Survey surveyDetails) {
		Survey survey = surveyRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Survey not exist with id :" + id));

		survey.setFirstName(surveyDetails.getFirstName());
		survey.setLastName(surveyDetails.getLastName());
		survey.setStreetAddress(surveyDetails.getStreetAddress());
		survey.setCity(surveyDetails.getCity());
		survey.setState(surveyDetails.getState());
		survey.setZipCode(surveyDetails.getZipCode());
		survey.setTelephone(surveyDetails.getTelephone());
		survey.setEmailId(surveyDetails.getEmailId());

		Survey updatedSurvey = surveyRepository.save(survey);
		return ResponseEntity.ok(updatedSurvey);
	}

	// delete employee rest api
	@DeleteMapping("/surveys/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteSurvey(@PathVariable Long id) {
		Survey survey = surveyRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Survey not exist with id :" + id));

		Repository.delete(survey);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

}
