export class Survey {
    id: number;
    firstName: string;
    lastName: string;
    StreetAddress: string;
    City: string;
    State: string;
    ZipCode: string;
    Telephone: string;
    emailId: string;
}
